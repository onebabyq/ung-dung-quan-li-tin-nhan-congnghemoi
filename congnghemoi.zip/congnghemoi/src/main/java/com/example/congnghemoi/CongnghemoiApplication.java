package com.example.congnghemoi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CongnghemoiApplication {

	public static void main(String[] args) {
		SpringApplication.run(CongnghemoiApplication.class, args);
	}

}
