package com.example.demobuckets3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoBucketS3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
