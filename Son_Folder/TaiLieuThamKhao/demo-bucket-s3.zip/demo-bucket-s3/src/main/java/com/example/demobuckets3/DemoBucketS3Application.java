package com.example.demobuckets3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoBucketS3Application {

	public static void main(String[] args) {
		SpringApplication.run(DemoBucketS3Application.class, args);
	}

}
